# 🎮 Wumpus Squad — Complete Setup Guide
## GitHub Upload + iOS IPA Build

---

## PART 1 — Set Up Your Project Locally

### Step 1: Install Node.js
Download from: https://nodejs.org (choose LTS version)

### Step 2: Create the project folder
Unzip the files you downloaded. Your folder should look like:
```
wumpus-squad/
├── src/
│   ├── App.jsx
│   └── main.jsx
├── index.html
├── package.json
├── vite.config.js
├── .env.example
└── .gitignore
```

### Step 3: Install dependencies
Open Terminal (Mac) or Command Prompt (Windows), navigate to the folder:
```bash
cd wumpus-squad
npm install
```

### Step 4: Test it works
```bash
npm run dev
```
Open http://localhost:5173 in your browser ✓

---

## PART 2 — Set Up Google Login

1. Go to https://console.cloud.google.com
2. Click **"Select a project"** → **"New Project"** → Name it "Wumpus Squad" → Create
3. Go to **APIs & Services** → **OAuth consent screen**
   - Choose **External** → Fill in App name, your email → Save
4. Go to **APIs & Services** → **Credentials**
   - Click **"+ Create Credentials"** → **OAuth client ID**
   - Application type: **Web application**
   - Name: Wumpus Squad
   - Authorized JavaScript origins: Add your domain (e.g. `https://yourdomain.com`)
   - Authorized redirect URIs: `https://yourdomain.com/auth/google/callback`
   - Click **Create**
5. Copy the **Client ID** (looks like: `123456789-abc.apps.googleusercontent.com`)
6. Create a file called `.env` in your project root:
```
VITE_GOOGLE_CLIENT_ID=paste_your_client_id_here
VITE_FACEBOOK_APP_ID=your_facebook_app_id_here
```

---

## PART 3 — Set Up Facebook Login

1. Go to https://developers.facebook.com
2. Click **My Apps** → **Create App** → Choose **Consumer** → Next
3. App name: "Wumpus Squad" → Create App
4. On the dashboard, find **Facebook Login** → click **Set Up** → choose **Web**
5. Site URL: your domain (e.g. `https://yourdomain.com`)
6. Go to **Facebook Login** → **Settings** in the left sidebar
7. Valid OAuth Redirect URIs: `https://yourdomain.com/auth/facebook/callback`
8. Save Changes
9. Go to **Settings** → **Basic** → copy the **App ID**
10. Add to your `.env` file:
```
VITE_FACEBOOK_APP_ID=paste_your_app_id_here
```

---

## PART 4 — Upload to GitHub

### Step 1: Install Git
Download from: https://git-scm.com

### Step 2: Create GitHub account
Go to https://github.com and sign up

### Step 3: Create a new repository
- Click the **+** button → **New repository**
- Name: `wumpus-squad`
- Set to **Public** or **Private**
- Do NOT initialize with README (you already have files)
- Click **Create repository**

### Step 4: Push your code
In Terminal inside your project folder:
```bash
git init
git add .
git commit -m "Initial commit - Wumpus Squad app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/wumpus-squad.git
git push -u origin main
```
Replace `YOUR_USERNAME` with your GitHub username.

### Step 5: Set environment variables on GitHub
- Go to your repo → **Settings** → **Secrets and variables** → **Actions**
- Click **New repository secret**
- Add: `VITE_GOOGLE_CLIENT_ID` = your Google client ID
- Add: `VITE_FACEBOOK_APP_ID` = your Facebook app ID

---

## PART 5 — Deploy to Web (Vercel — Free)

1. Go to https://vercel.com and sign in with GitHub
2. Click **"New Project"** → Import your `wumpus-squad` repo
3. Framework: **Vite** (auto-detected)
4. Environment Variables: Add your Google and Facebook IDs
5. Click **Deploy**
6. Your app goes live at `https://wumpus-squad.vercel.app` ✓

Update your Google/Facebook redirect URIs to use this domain.

---

## PART 6 — Build iOS IPA

### What you need:
- A **Mac** computer (required for iOS builds)
- **Xcode** installed (free from Mac App Store)
- **Apple Developer account** ($99/year) for real device + App Store
  - OR use free account for testing on your own device only

### Method A: Using Capacitor (Recommended — easiest)

#### Step 1: Install Capacitor
```bash
npm install @capacitor/core @capacitor/cli @capacitor/ios
npx cap init "Wumpus Squad" "com.yourname.wumpussquad"
```

#### Step 2: Build the web app
```bash
npm run build
```

#### Step 3: Add iOS platform
```bash
npx cap add ios
npx cap copy ios
```

#### Step 4: Open in Xcode
```bash
npx cap open ios
```

#### Step 5: In Xcode:
- Select your Team (Apple ID) in **Signing & Capabilities**
- Change Bundle Identifier to something unique: `com.yourname.wumpussquad`
- Select **Any iOS Device** as target
- Go to **Product** → **Archive**
- When done, click **Distribute App** → **Ad Hoc** or **App Store**
- Export → you get your `.ipa` file ✓

### Method B: Using GitHub Actions (Build in cloud, no Mac needed)

Create `.github/workflows/ios.yml` in your repo:

```yaml
name: Build iOS IPA
on:
  push:
    branches: [main]
jobs:
  build:
    runs-on: macos-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: npm install
      - run: npm run build
        env:
          VITE_GOOGLE_CLIENT_ID: ${{ secrets.VITE_GOOGLE_CLIENT_ID }}
          VITE_FACEBOOK_APP_ID: ${{ secrets.VITE_FACEBOOK_APP_ID }}
      - run: npm install @capacitor/core @capacitor/cli @capacitor/ios
      - run: npx cap add ios
      - run: npx cap copy ios
      - name: Build IPA
        uses: yukiarrr/ios-build-action@v1.5.0
        with:
          project-path: ios/App/App.xcodeproj
          p12-base64: ${{ secrets.P12_BASE64 }}
          mobileprovision-base64: ${{ secrets.MOBILEPROVISION_BASE64 }}
          code-signing-identity: "iPhone Distribution"
      - uses: actions/upload-artifact@v4
        with:
          name: wumpus-squad.ipa
          path: "*.ipa"
```

For GitHub Actions iOS build you also need:
- A `.p12` certificate from your Apple Developer account
- A provisioning profile

### Method C: Use a service (No Mac, No coding)

Services that build IPA from web apps for free/cheap:
- **Ionic Appflow**: https://ionic.io/appflow
- **PhoneGap Build**: Adobe's cloud builder
- **Expo EAS**: https://expo.dev/eas (if you convert to React Native)

---

## PART 7 — Install IPA on iPhone (without App Store)

### Option 1: AltStore (Free, no jailbreak)
1. Install AltServer on your Mac/PC: https://altstore.io
2. Install AltStore on your iPhone via AltServer
3. Open AltStore → tap **+** → select your `.ipa` file
4. App installs! (needs refresh every 7 days with free Apple ID)

### Option 2: Sideloadly (Free)
1. Download Sideloadly: https://sideloadly.io
2. Connect iPhone via USB
3. Drag your `.ipa` into Sideloadly
4. Enter your Apple ID → Install

### Option 3: Apple TestFlight (For sharing with others)
1. Upload IPA to App Store Connect: https://appstoreconnect.apple.com
2. Create a TestFlight group → Add testers by email
3. Testers install via TestFlight app (no App Store review needed)

---

## Quick Reference

| Task | Command |
|------|---------|
| Run locally | `npm run dev` |
| Build for production | `npm run build` |
| Sync to iOS | `npx cap copy ios` |
| Open Xcode | `npx cap open ios` |
| Push to GitHub | `git add . && git commit -m "update" && git push` |

## Need Help?

- Capacitor docs: https://capacitorjs.com/docs
- Vite docs: https://vitejs.dev
- GitHub docs: https://docs.github.com
- Apple Developer: https://developer.apple.com
